def calculate_bmi(weight_kg, height_cm):
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2)
    return round(bmi, 2)

def bmi_category(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 24.9:
        return "Normal weight"
    elif 25 <= bmi < 29.9:
        return "Overweight"
    else:
        return "Obesity"

def main():
    print("BMI Calculator")
    weight = float(input("Enter your weight in kg: "))
    height = float(input("Enter your height in cm: "))
    bmi = calculate_bmi(weight, height)
    category = bmi_category(bmi)
    print(f"Your BMI is: {bmi}")
    print(f"You are classified as: {category}")

if __name__ == "__main__":
    main()
