# AI & ML Projects by Avdhut Ananda Satpute

## Python Mini Projects
- BMI Calculator: Simple Python program to calculate Body Mass Index and classify weight.

## Machine Learning Notebooks
- Iris Flower Classification: KNN based classification on Iris dataset with accuracy evaluation.

---

Feel free to explore and use these projects to learn and practice AI/ML basics.
